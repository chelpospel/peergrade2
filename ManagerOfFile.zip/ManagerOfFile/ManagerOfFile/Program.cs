﻿using System;
using System.Collections.Specialized;
using System.IO;
using System.Security;
using System.Text;

namespace ManagerOfFile
{
    internal class Program
    {
        
        
        public static string[] Drives()
        {
            try
            {
                Console.Clear();
                DriveInfo[] allDrives = DriveInfo.GetDrives();
                int i = 0;
                string[] rezult = new string[allDrives.Length];
                foreach (DriveInfo d in allDrives)
                {
                    rezult[i] = d.Name;
                    i++;
                }
                    
                return rezult;
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                return null;
            }
                
        }
        
        public static string[] DirecoryOverview(string path)
        {
            try
            {
                var directories = Directory.GetDirectories(path);
                if (directories.Length == 0)
                    directories = Directory.GetFiles(path);
                return directories;
            }
            catch (IOException ex)
            {
                Console.WriteLine($" Произошла ошибка ввода/вывода {ex.Message}");
                return null;
            }
            catch (System.Security.SecurityException ex)
            {
                Console.WriteLine($" Произошла ошибка безопасноти: {ex.Message}");
                return null;
            }
        }

        public static void ClearLine()
        {
            int cursorTop = Console.CursorTop;
            string print = " ";
            for (int i = 0; i < Console.BufferWidth - 2; i++)
                print += " ";
            Console.SetCursorPosition(0,cursorTop);
            Console.Write(print);
            Console.SetCursorPosition(0, cursorTop);
        }
        
        public static void WriteLineColoredText( string[] text, int nowCursorTop, int start)
        {
            int cursorLeft = Console.CursorLeft;
            int cursorTop = Console.CursorTop;
            Console.SetCursorPosition(0,0);
            for (int i = 0; (i < Console.BufferHeight)&&(i < text.Length - start); i++)
            {
                ClearLine();
                if (i == nowCursorTop)
                {
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write(text[start + nowCursorTop]);
                    Console.ForegroundColor = ConsoleColor.Black;
                    if(i == Console.BufferHeight - 1)
                        Console.SetCursorPosition(0,Console.CursorTop - 1);
                    else
                        Console.SetCursorPosition(0,Console.CursorTop+1);
                }
                else
                {
                    Console.Write(text[start + i]);
                    if (i == Console.BufferHeight - 1 )
                        Console.SetCursorPosition(0,Console.CursorTop - 1);
                    else
                        Console.SetCursorPosition(0,Console.CursorTop+1);
                }
            }
            Console.SetCursorPosition(cursorLeft, cursorTop);
        }

        public static int MoveCursor(ref int left, ref int top)
        {
            if (left < 0)
                left = 0;
            if (left > Console.BufferWidth - 1)
                left = Console.BufferWidth - 1;
            if (top < 0)
            {
                top = 0;
                return -1;
            }

            if (top > Console.BufferHeight - 1)
            {
                top = Console.BufferHeight - 1;
                return 1;
            }
            Console.SetCursorPosition(left, top);
            return 0;
        }

        public static string[] Move(string[] text)
        {
            Console.Clear();
            var key = new ConsoleKeyInfo();
            int cursorPosLeft = Console.CursorLeft;
            int cursorPosTop = Console.CursorTop;
            int buffer = 0;
            int nowCursorTop = 0;
            int start = 0;
                
            while (key.Key != ConsoleKey.Backspace && key.Key != ConsoleKey.Enter && key.Key != ConsoleKey.F && 
                   key.Key != ConsoleKey.Escape && key.Key != ConsoleKey.Q && key.Key != ConsoleKey.Tab
                   && key.Key != ConsoleKey.R && key.Key != ConsoleKey.T)
            {
                switch (key.Key)
                {
                    case ConsoleKey.UpArrow:
                        cursorPosTop--;
                        buffer = MoveCursor(ref cursorPosLeft, ref cursorPosTop);
                        break;
                    case ConsoleKey.DownArrow:
                        cursorPosTop++;
                        buffer = MoveCursor(ref cursorPosLeft, ref cursorPosTop);
                        break;
                    case ConsoleKey.LeftArrow:
                        cursorPosLeft--;
                        buffer = MoveCursor(ref cursorPosLeft, ref cursorPosTop) - 1;
                        break;
                    case ConsoleKey.RightArrow:
                        cursorPosLeft++;
                        buffer = MoveCursor(ref cursorPosLeft, ref cursorPosTop) - 1;
                        break;
                }

                start += buffer;
                if (start < 0)
                    start = 0;

                if (start + cursorPosTop > text.Length-1)
                {
                    cursorPosTop--;
                    Console.SetCursorPosition(cursorPosLeft, cursorPosTop);
                }


                nowCursorTop = Console.CursorTop;
                WriteLineColoredText(text, nowCursorTop, start);
                key = Console.ReadKey();
                while (key.Key != ConsoleKey.Enter && key.Key != ConsoleKey.RightArrow && key.Key != ConsoleKey.LeftArrow && 
                       key.Key != ConsoleKey.UpArrow && key.Key != ConsoleKey.DownArrow && key.Key != ConsoleKey.Backspace && 
                       key.Key != ConsoleKey.Escape && key.Key != ConsoleKey.F && key.Key != ConsoleKey.Q && key.Key != ConsoleKey.Tab
                       && key.Key != ConsoleKey.R && key.Key != ConsoleKey.T)
                {
                    key = Console.ReadKey();
                }
            }

            
            string[] rezult = new string[2];

            // Если пользователь хочет углубиться в директорию.
            if (key.Key == ConsoleKey.Enter)
            {
                rezult[0] = "Enter";
                rezult[1] = text[start + nowCursorTop];
            }

            // Если пользователь хочет посмотреть содержимое текстового файла.
            if (key.Key == ConsoleKey.R)
            {
                rezult[0] = "R";
                rezult[1] = text[start + nowCursorTop];
            }
            
            // Если пользователь хочет посмотреть содержимое текстового файла в выбранной им кодировке.
            if (key.Key == ConsoleKey.T)
            {
                rezult[0] = "T";
                rezult[1] = text[start + nowCursorTop];
            }

            // Если пользователь хочет вернуться в предудущюю родительскую директорию.
            if (key.Key == ConsoleKey.Backspace)
            {
                rezult[0] = "Backspace";
                rezult[1] = "";
            }

            // Если пользователь хочет посмотреть список файлов выбранной директории.
            if (key.Key == ConsoleKey.F)
            {
                rezult[0] = "F";
                rezult[1] = text[start + nowCursorTop];
            }

            // Если пользователь хочет посмотреть МЕНЮ ОПЕРАЦИЙ.
            if (key.Key == ConsoleKey.Q)
            {
                rezult[0] = "Q";
            }

            // Если пользователь хочет завершить выполнение программы.
            if (key.Key == ConsoleKey.Escape)
            {
                rezult[0] = "Escape";
            }
            
            // Если пользователь хочет удалить данный файл
            if (key.Key == ConsoleKey.Tab)
            {
                rezult[0] = "Tab";
                rezult[1] = text[start + nowCursorTop];
            }


            return rezult;
        }


        public static void Menu()
        {
            
            Console.WriteLine("МЕНЮ ОПЕРАЦИЙ");
            Console.WriteLine();
            Console.WriteLine("Enter - углубиться в данную директорию");
            Console.WriteLine("Tab - удалить данный файл");
            Console.WriteLine("Backspace - вернуться в исходную(родительскую) директорию");
            Console.WriteLine("Escape - завершить выполнение программу");
            Console.WriteLine("F - посмотреть файлы внутри данной директории");
            Console.WriteLine("R - вывести в консоль содержимое текстового файла в кодировке UTF-8");
            Console.WriteLine("T - вывести в консоль содержимое текстового файла в кодировке UTF-8");
            Console.WriteLine("Q - открыть МЕНЮ ОПЕРАЦИЙ");
            Console.WriteLine();
            Console.WriteLine("Чтобы выйти из меню, нажмите любую клавишу...");
            Console.ReadKey();
        }

        public static string EncodeOfChoose()
        {
            Console.Clear();
            Console.WriteLine("Выберите кодировку, в которой хотите просмотреть содержимое текстового файла: ");
            string[] encode = {"UTF8", "UTF7", "UTF32", "ASCII"};
            string rezult = Move(encode)[1];
            Console.Clear();
            return rezult;

        }
        
        
        
        public static void Main(string[] args)
        {
            var k = new ConsoleKeyInfo();
            while (k.Key != ConsoleKey.Escape)
            {
               string[] text = Drives();
               string[] chek = new string[2];
               string path_now = "", path_last, path_post_last = "";
               Menu();
               Console.CursorVisible = false;
               try
               {
                   while (text.Length != 0)
                   {
                       // Запоминаем путь до директории, в которой находимся в данный момент цикла.
                       path_last = path_now;
                       chek = Move(text);


                       switch (chek[0])
                       {
                           case "Backspace":
                               try
                               {
                                   path_now = Directory.GetParent(path_last).FullName;
                                   text = Directory.GetDirectories(path_now);
                               }
                               catch (Exception e)
                               {
                                   text = Drives();
                               }

                               break;

                           case "F":
                               if (Directory.Exists(chek[1]) == false)
                               {
                                   Console.Clear();
                                   Console.WriteLine("Данный объект не является директорией: " + chek[1]);
                                   Console.WriteLine("Нажмите любую клавишу, чтобы вернуться назад...");
                                   Console.CursorVisible = true;
                                   Console.ReadKey();
                                   Console.CursorVisible = false;
                                   break;
                               }

                               try
                               {
                                   if (Directory.GetFiles(chek[1]).Length == 0)
                                   {
                                       Console.Clear();
                                       Console.Write("В директории " + chek[1] + " нет файлов.");
                                       Console.WriteLine("Нажмите любую клавишу, чтобы вернуться назад...");
                                       Console.CursorVisible = true;
                                       Console.ReadKey();
                                       Console.CursorVisible = false;
                                   }
                                   else
                                   {
                                       path_post_last = path_now;
                                       path_now = chek[1];
                                       text = Directory.GetFiles(path_now);
                                   }

                               }
                               catch (Exception e)
                               {
                                   Console.Write(e.Message);
                               }

                               break;

                           case "Escape":
                               return;

                           case "Q":
                               Console.Clear();
                               Menu();
                               break;

                           case "Enter":
                               if (!Directory.Exists(chek[1]))
                               {
                                   Console.Clear();
                                   Console.WriteLine("Данный объект не является директорией: " + chek[1]);
                                   Console.WriteLine("Нажмите любую клавишу, чтобы вернуться назад...");
                                   Console.WriteLine();
                                   Console.CursorVisible = true;
                                   Console.ReadKey();
                                   Console.CursorVisible = false;
                               }
                               else if (Directory.GetDirectories(chek[1]).Length == 0)
                               {
                                   Console.Clear();
                                   Console.WriteLine("В указанном объекте " + chek[1] + " нет директорий.");
                                   Console.WriteLine("Нажмите любую клавишу, чтобы вернуться назад...");
                                   Console.WriteLine();
                                   Console.CursorVisible = true;
                                   Console.ReadKey();
                                   Console.CursorVisible = false;
                               }
                               else
                               {
                                   text = Directory.GetDirectories(chek[1]);
                                   path_now = chek[1];
                               }

                               break;

                           case "Tab":
                               if (File.Exists(chek[1]))
                               {
                                   Console.Clear();
                                   Console.CursorVisible = true;
                                   Console.WriteLine("Нажмите Enter и подтвердите, что хотите удалить файл: " +
                                                     chek[1]);
                                   var key = Console.ReadKey();
                                   if (key.Key == ConsoleKey.Enter)
                                       File.Delete(chek[1]);

                                   Console.CursorVisible = false;
                                   if (Directory.GetFiles(path_now).Length == 0)
                                       text = Directory.GetFiles(path_post_last);
                                   else
                                       text = Directory.GetFiles(path_now);
                               }
                               else
                               {
                                   Console.Clear();
                                   Console.WriteLine("Данный объект не является файлом.");
                                   Console.WriteLine("Нажмите любую клавишу, чтобы вернуться назад...");
                                   Console.WriteLine();
                                   Console.CursorVisible = true;
                                   Console.ReadKey();
                                   Console.CursorVisible = false;
                               }

                               break;

                           case "R":
                               if (File.Exists(chek[1]) == false)
                               {
                                   Console.Clear();
                                   Console.WriteLine("Данный объект не является файлом.");
                                   Console.WriteLine("Нажмите любую клавишу, чтобы вернуться назад...");
                                   Console.WriteLine();
                                   Console.CursorVisible = true;
                                   Console.ReadKey();
                                   Console.CursorVisible = false;
                                   break;
                               }

                               string extension = Path.GetExtension(chek[1]);
                               if (string.Compare(extension, ".txt") == 0)
                               {
                                   Console.Clear();
                                   Console.Write(File.ReadAllText(chek[1]));

                                   Console.ForegroundColor = ConsoleColor.Green;
                                   Console.WriteLine();
                                   Console.WriteLine("Нажмите любую клавишу, чтобы вернуться назад...");
                                   Console.WriteLine();
                                   Console.CursorVisible = true;
                                   Console.ReadKey();
                                   Console.ForegroundColor = ConsoleColor.Black;
                                   Console.CursorVisible = false;
                               }
                               else
                               {
                                   Console.Clear();
                                   Console.WriteLine(
                                       $"Данный объект не является текстовым файлом. Он имеет расширение: {extension}");
                                   Console.WriteLine("Нажмите любую клавишу, чтобы вернуться назад...");
                                   Console.WriteLine();
                                   Console.CursorVisible = true;
                                   Console.ReadKey();
                                   Console.CursorVisible = false;
                               }

                               break;

                           case "T":
                               if (File.Exists(chek[1]) == false)
                               {
                                   Console.Clear();
                                   Console.WriteLine("Данный объект не является файлом.");
                                   Console.WriteLine("Нажмите любую клавишу, чтобы вернуться назад...");
                                   Console.WriteLine();
                                   Console.CursorVisible = true;
                                   Console.ReadKey();
                                   Console.CursorVisible = false;
                                   break;
                               }

                               extension = Path.GetExtension(chek[1]);
                               if (string.Compare(extension, ".txt") == 0)
                               {
                                   string str = EncodeOfChoose();
                                   switch (str)
                                   {
                                       case "UTF8)":
                                           Console.Write(File.ReadAllText(chek[1], Encoding.UTF8));
                                           break;

                                       case "UTF7":
                                           Console.Write(File.ReadAllText(chek[1], Encoding.UTF7));
                                           break;

                                       case "UTF32)":
                                           Console.Write(File.ReadAllText(chek[1], Encoding.UTF32));
                                           break;

                                       case "ASCII)":
                                           Console.Write(File.ReadAllText(chek[1], Encoding.ASCII));
                                           break;
                                   }

                                   Console.ForegroundColor = ConsoleColor.Green;
                                   Console.WriteLine();
                                   Console.WriteLine("Нажмите любую клавишу, чтобы вернуться назад...");
                                   Console.WriteLine();
                                   Console.CursorVisible = true;
                                   Console.ReadKey();
                                   Console.ForegroundColor = ConsoleColor.Black;
                                   Console.CursorVisible = false;
                               }
                               else
                               {
                                   Console.Clear();
                                   Console.WriteLine(
                                       $"Данный объект не является текстовым файлом. Он имеет расширение: {extension}");
                                   Console.WriteLine("Нажмите любую клавишу, чтобы вернуться назад...");
                                   Console.CursorVisible = true;
                                   Console.ReadKey();
                                   Console.CursorVisible = false;
                               }

                               break;
                       }
                   }
               }
               catch (Exception exception)
               {
                   Console.Clear();
                   Console.WriteLine(exception.Message);
                   Console.WriteLine("Что-то пошло не так. Давайте попробуем заново.");
                   Console.WriteLine("Нажмите любую клавишу, что выйти на повторение программы...");
                   Console.WriteLine();
                   Console.ReadKey();
               }

               Console.Clear();
               Console.Write("Если желаете повторить программу, то нажмите любую кнопку, кроме Esape.");
               k = Console.ReadKey();
            }
        }
    }
}